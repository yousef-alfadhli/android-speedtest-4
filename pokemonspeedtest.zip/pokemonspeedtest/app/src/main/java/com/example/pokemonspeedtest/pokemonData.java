package com.example.pokemonspeedtest;

public class pokemonData {
}
